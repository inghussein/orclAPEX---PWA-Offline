const dbName = 'apexOfflineDB';
const storeName = 'registros';
const dbVersion = 1;

window.addEventListener('online', () => {
    apex.message.clearErrors();
    apex.message.showPageSuccess('Conexión a internet recuperada.!');

  const req = indexedDB.open('apexOfflineDB', dbVersion);
  req.onsuccess = event => {
    const db = event.target.result;
    const tx = db.transaction(storeName, 'readonly');
    const store = tx.objectStore(storeName);
    const all = store.getAll();

    all.onsuccess = () => {
      all.result.forEach(reg => {

        apex.server.process('insercion', {
          x01: JSON.stringify(reg)
        }, {
          success: () => {
            const txDel = db.transaction(storeName, 'readwrite');
            const storeDel = txDel.objectStore(storeName);
            storeDel.clear(); // Borra todos
            apex.message.showPageSuccess('Registros sincronizados!');
            $.event.trigger("daSubmit");
          }
        });
      });
    };
  };
});

window.addEventListener('offline', () => {

apex.message.clearErrors();
        apex.message.showErrors([{
            type: 'info',
            location: 'page',
            message: 'Sin conexión a internet. Los registros se guardarán offline.'
        }]);

});



function saveDataToIndexedDB (){

const nuevoRegistro = {
  nombre: $v('P1_NOMBRE'),
  fecha: $v('P1_FECHA'),
  usuario: $v('P1_USUARIO'),
};

// Abrir la base de datos
const request = indexedDB.open(dbName, dbVersion);

// Crear el object store si no existe
request.onupgradeneeded = function(event) {
  const db = event.target.result;
  if (!db.objectStoreNames.contains(storeName)) {
    db.createObjectStore(storeName, { autoIncrement: true });
  }
};

// Guardar el dato en IndexedDB
request.onsuccess = function(event) {
  const db = event.target.result;

  if (!db.objectStoreNames.contains(storeName)) {
    console.log(`El object store '${storeName}' no existe aún.`);
    apex.message.showErrors([{
      type: 'error',
      location: 'page',
      message: `El almacenamiento offline no está listo. Por favor intenta más tarde.`
    }]);
    return;
  }

  const tx = db.transaction(storeName, 'readwrite');
  const store = tx.objectStore(storeName);
  store.add(nuevoRegistro);

  apex.message.clearErrors();
  apex.message.showPageSuccess('Registro guardado localmente');
  
  $s("P1_NOMBRE", "");

  contarRegistrosOffline((cantidad) => {
    apex.item("P1_CANT_OFFLINE").setValue(cantidad);
  });

  mostrarRegistrosOffline();


};


}

function mostrarRegistrosOffline() {
  const req = indexedDB.open('apexOfflineDB', dbVersion);
  
  req.onsuccess = event => {
    const db = event.target.result;
    const tx = db.transaction(storeName, 'readonly');
    const store = tx.objectStore(storeName);
    const getAll = store.getAll();

    getAll.onsuccess = () => {
      const registros = getAll.result;
      let html = `
        <div class="t-Region t-Region--scrollBody">
          <div class="t-Region-header">
            <div class="t-Region-headerItems t-Region-headerItems--title">
              <h2 class="t-Region-title">📦 Registros Offline</h2>
            </div>
          </div>
          <div class="t-Region-bodyWrap">
            <div class="t-Region-body">
              <div class="a-IRR-tableContainer">
                <table class="a-IRR-table" summary="Registros Offline">
                  <thead>
                    <tr>
                      <th class="a-IRR-header">Nombre</th>
                      <th class="a-IRR-header">Fecha</th>
                      <th class="a-IRR-header">Usuario</th>
                    </tr>
                  </thead>
                  <tbody>`;

      if (registros.length === 0) {
        html += `
          <tr>
            <td colspan="3" style="text-align:center;">No hay registros offline</td>
          </tr>`;
      } else {
        registros.forEach(reg => {
          html += `
            <tr>
              <td>${reg.nombre}</td>
              <td>${reg.fecha}</td>
              <td>${reg.usuario}</td>
            </tr>`;
        });
      }

      html += `
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>`;

      document.getElementById('offlineDataContainer').innerHTML = html;
    };
  };
}

document.addEventListener('DOMContentLoaded', () => {
  initIndexedDB();
});

function contarRegistrosOffline(callback) {
  const req = indexedDB.open("apexOfflineDB", dbVersion); 

  req.onsuccess = event => {
    const db = event.target.result;

    if (!db.objectStoreNames.contains(storeName)) {
      console.warn("El object store 'registros' no existe aún.");
      if (callback) callback(0);
      return;
    }

    const tx = db.transaction(storeName, "readonly");
    const store = tx.objectStore(storeName);
    const countRequest = store.count();

    countRequest.onsuccess = () => {
      const total = countRequest.result;
      if (callback) callback(total);
    };

    countRequest.onerror = () => {
      console.log("Error al contar registros.");
      if (callback) callback(0);
    };
  };

  req.onerror = () => {
    console.log("Error al abrir IndexedDB.");
    if (callback) callback(0);
  };
}




function initIndexedDB() {
  const request = indexedDB.open('apexOfflineDB', dbVersion);

  request.onupgradeneeded = function(event) {
    const db = event.target.result;
    if (!db.objectStoreNames.contains(storeName)) {
      db.createObjectStore(storeName, { autoIncrement: true });
    }
  };

  request.onsuccess = function(event) {
    // Nada más, solo inicializa
    console.log('IndexedDB lista');

    contarRegistrosOffline((cantidad) => {
    apex.item("P1_CANT_OFFLINE").setValue(cantidad);
    });

  };
}